package com.cg.mpa.dao;

import com.cg.mpa.entities.PurchaseDetails;

public interface PurchaseDetailsDao
{

	void insertPurchaseDetails(PurchaseDetails pdetails);
}
