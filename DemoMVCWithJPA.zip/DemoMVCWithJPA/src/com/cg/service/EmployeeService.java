package com.cg.service;

import com.cg.entities.Employee;

public interface EmployeeService
{

	int insertEmp(Employee emp);
}
